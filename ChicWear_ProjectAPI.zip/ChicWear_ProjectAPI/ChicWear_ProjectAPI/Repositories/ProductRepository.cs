﻿using ChicWear_ProjectAPI.Models;
using ChicWear_ProjectAPI.Data;
using Microsoft.EntityFrameworkCore;

namespace ChicWear_ProjectAPI.Repositories
{

    // Repositories/ProductRepository.cs
    public class ProductRepository : IProductRepository
    {
        private readonly AppDbContext _context;

        public ProductRepository(AppDbContext context)
        {
            _context = context;
        }

        public async Task<List<Product>> GetAllAsync(string category = null)
        {
            var query = _context.Products.Include(p => p.Category).AsQueryable();

            if (!string.IsNullOrEmpty(category) && category != "All")
            {
                query = query.Where(p => p.Category.Name == category);
            }

            return await query.ToListAsync();
        }

        public async Task<List<Product>> GetFeaturedAsync()
        {
            return await _context.Products
                .Where(p => p.IsFeatured)
                .Take(4)
                .ToListAsync();
        }

        // Get a single product by ID including its category
        public async Task<Product?> GetByIdAsync(int id)
        {
            return await _context.Products
                .Include(p => p.Category)
                .FirstOrDefaultAsync(p => p.Id == id);
        }
    }


}
