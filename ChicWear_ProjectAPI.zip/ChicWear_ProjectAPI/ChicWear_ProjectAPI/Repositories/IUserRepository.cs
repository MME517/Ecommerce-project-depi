﻿using ChicWear_ProjectAPI.Models;

namespace ChicWear_ProjectAPI.Repositories
{
    public interface IUserRepository
    {
        Task<ApplicationUser> GetUserProfileAsync(string sessionId);
    }
}
