﻿using ChicWear_ProjectAPI.Models;

namespace ChicWear_ProjectAPI.Repositories
{
    public class UserRepository : IUserRepository
    {
        public async Task<ApplicationUser> GetUserProfileAsync(string sessionId)
        {
            return new ApplicationUser
            {
                UserName = "Hana Ahmed",
                Email = "hana.ahmed@example.com",
                Avatar = "/images/woman3.jpg",
                Orders = new List<Order>
                {
                    new Order
                    {
                        Id = 1,
                        Date = new DateTime(2025, 4, 10),
                        Total = 99.98m,
                        OrderItems = new List<OrderItem>
                        {
                            new OrderItem { ProductId = 101, Quantity = 1, PriceAtPurchase = 55.00m }, // "Floral Maxi Dress"
                            new OrderItem { ProductId = 102, Quantity = 1, PriceAtPurchase = 44.98m }  // "Silk Blouse"
                        }
                    },
                    new Order
                    {
                        Id = 2,
                        Date = new DateTime(2025, 3, 15),
                        Total = 44.99m,
                        OrderItems = new List<OrderItem>
                        {
                            new OrderItem { ProductId = 103, Quantity = 1, PriceAtPurchase = 44.99m } // "High-Waisted Jeans"
                        }
                    }
                }
            };
        }
    }

}
