﻿using ChicWear_ProjectAPI.Models;
using ChicWear_ProjectAPI.Data;
using Microsoft.EntityFrameworkCore;


namespace ChicWear_ProjectAPI.Repositories
{
    public class ShippingRepository : IShippingRepository
    {
        private readonly AppDbContext _context;

        public ShippingRepository(AppDbContext context)
        {
            _context = context;
        }

        public async Task<ShippingInfo> AddShippingInfoAsync(ShippingInfo shippingInfo)
        {
            _context.ShippingInfos.Add(shippingInfo);
            await _context.SaveChangesAsync();
            return shippingInfo;
        }
        public async Task<Product> GetByIdAsync(int id)
        {
            return await _context.Products.FirstOrDefaultAsync(p => p.Id == id);
        }

    }
}
