﻿using ChicWear_ProjectAPI.Models;

namespace ChicWear_ProjectAPI.Repositories
{
    public interface IShippingRepository
    {
        Task<ShippingInfo> AddShippingInfoAsync(ShippingInfo shippingInfo);
        Task<Product> GetByIdAsync(int id);
    }
}
