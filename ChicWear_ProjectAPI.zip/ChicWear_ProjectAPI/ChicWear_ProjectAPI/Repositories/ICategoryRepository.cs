﻿using ChicWear_ProjectAPI.Models;

namespace ChicWear_ProjectAPI.Repositories
{
    public interface ICategoryRepository
    {
        Task<List<Category>> GetAllAsync();
    }
}
