﻿using ChicWear_ProjectAPI.Models;


namespace ChicWear_ProjectAPI.Repositories
{
    public interface IProductRepository
    {
        Task<List<Product>> GetAllAsync(string category = null);
        Task<List<Product>> GetFeaturedAsync();
        Task<Product> GetByIdAsync(int id);

    }
}
