﻿using ChicWear_ProjectAPI.Models;
using ChicWear_ProjectAPI.Repositories;
using ChicWear_ProjectAPI.ViewModels;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace ChicWear_ProjectAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ShippingController : ControllerBase
    {
        private readonly IShippingRepository _repository;

        public ShippingController(IShippingRepository repository)
        {
            _repository = repository;
        }

        [HttpPost]
        public async Task<IActionResult> CreateShippingInfo([FromBody] ShippingInfoViewModel model)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            var shippingInfo = new ShippingInfo
            {
                FullName = model.FullName,
                Address = model.Address,
                City = model.City,
                ZipCode = model.ZipCode
            };

            var result = await _repository.AddShippingInfoAsync(shippingInfo);

            HttpContext.Session.SetInt32("UserShippingId", result.Id);
            HttpContext.Session.SetString("UserName", result.FullName);

            return Ok(result);
        }

        [HttpGet("me")]
        public async Task<IActionResult> GetCurrentUserShipping()
        {
            var userId = HttpContext.Session.GetInt32("UserShippingId");

            if (userId == null)
                return Unauthorized("No user session found");

            var shippingInfo = await _repository.GetByIdAsync(userId.Value);

            if (shippingInfo == null)
                return NotFound("User not found");

            return Ok(shippingInfo);
        }

    }

}
