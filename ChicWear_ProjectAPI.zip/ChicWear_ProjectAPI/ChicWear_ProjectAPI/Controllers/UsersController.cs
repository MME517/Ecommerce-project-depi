﻿using ChicWear_ProjectAPI.Models;
using ChicWear_ProjectAPI.Repositories;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace ChicWear_ProjectAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UsersController : ControllerBase
    {
        private readonly IUserRepository _userRepo;

        public UsersController(IUserRepository userRepo)
        {
            _userRepo = userRepo;
        }

        [HttpGet("profile")]
        public async Task<ActionResult<ApplicationUser>> GetProfile()
        {
            
            var sessionId = HttpContext.Session.GetString("SessionID");
            if (string.IsNullOrEmpty(sessionId)) return Unauthorized();

            var profile = await _userRepo.GetUserProfileAsync(sessionId);
            return Ok(profile);
        }
    }
}
