﻿using ChicWear_ProjectAPI.Repositories;
using ChicWear_ProjectAPI.ViewModels;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ChicWear_ProjectAPI.Data;
using Microsoft.EntityFrameworkCore;
using ChicWear_ProjectAPI.Models;



namespace ChicWear_ProjectAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductController : ControllerBase
    {
        private readonly IProductRepository _productRepository;
        private readonly AppDbContext _context;

        public ProductController(IProductRepository productRepository, AppDbContext context)
        {
            _productRepository = productRepository;

            _context = context;
        }



        [HttpGet]
        public async Task<ActionResult<IEnumerable<ProductViewModel>>> GetProducts()
        {


            var products = await _productRepository.GetAllAsync();

            // 🟨 Manual mapping from Product to ProductViewModel
            var productViewModels = products.Select(p => new ProductViewModel
            {
                Id = p.Id,
                Name = p.Name,
                ImageUrl = p.ImageUrl,
                Price = p.Price,
                Description = p.Description,
                CategoryName = p.Category?.Name
            }).ToList();



            return Ok(productViewModels);
        }


        [HttpGet("{id}")]
        public IActionResult GetProductById(int id)
        {
            var product = _context.Products
                .Include(p => p.Category)
                .FirstOrDefault(p => p.Id == id);

            if (product == null)
                return NotFound();

            var result = new ProductViewModel
            {
                Id = product.Id,
                Name = product.Name,
                ImageUrl = product.ImageUrl,
                Price = product.Price,
                Description = product.Description,
                CategoryName = product.Category?.Name
            };


            return Ok(result);
        }

    }
}