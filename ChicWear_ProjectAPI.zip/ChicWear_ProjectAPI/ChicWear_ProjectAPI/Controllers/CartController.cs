﻿using ChicWear_ProjectAPI.Data;
using ChicWear_ProjectAPI.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;


namespace ChicWear_ProjectAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CartController : ControllerBase
    {
        private readonly AppDbContext _context;

        public CartController(AppDbContext context)
        {
            _context = context;
        }

        // ✅ Get All Cart Items
        [HttpGet]
        public async Task<ActionResult<IEnumerable<object>>> GetCartItems()
        {
            var cartItems = await _context.CartItems.Include(ci => ci.Product).ToListAsync();

            var result = cartItems.Select(ci => new
            {
                id = ci.Product.Id,
                name = ci.Product.Name,
                image = ci.Product.ImageUrl,
                price = ci.Product.Price,
                quantity = ci.Quantity
            });

            return Ok(result);
        }

        // ✅ Add or Update Quantity
        [HttpPost("update")]
        public async Task<IActionResult> UpdateQuantity(int productId, int quantity)
        {
            var cartItem = await _context.CartItems.FirstOrDefaultAsync(c => c.ProductId == productId);

            if (cartItem == null)
            {
                cartItem = new CartItem
                {
                    ProductId = productId,
                    Quantity = quantity
                };
                _context.CartItems.Add(cartItem);
            }
            else
            {
                cartItem.Quantity = quantity;
            }

            await _context.SaveChangesAsync();
            return Ok();
        }

        // ✅ Remove Item
        [HttpDelete("{productId}")]
        public async Task<IActionResult> RemoveFromCart(int productId)
        {
            var cartItem = await _context.CartItems.FirstOrDefaultAsync(c => c.ProductId == productId);

            if (cartItem == null)
                return NotFound();

            _context.CartItems.Remove(cartItem);
            await _context.SaveChangesAsync();

            return Ok();
        }
    }

}
