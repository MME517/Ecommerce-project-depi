﻿namespace ChicWear_ProjectAPI.Models
{
    public class ColorOption
    {
        public int Id { get; set; }
        public string ColorName { get; set; }

        public int ProductId { get; set; }
        public Product Product { get; set; }
    }
}
