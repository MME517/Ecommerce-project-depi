﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace ChicWear_ProjectAPI.Models
{
    public class Category
    {
            public int Id { get; set; }
            public string Name { get; set; }

            public ICollection<Product> Products { get; set; }
        
    }
}
