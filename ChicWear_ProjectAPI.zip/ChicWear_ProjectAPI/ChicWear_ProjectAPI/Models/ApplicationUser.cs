﻿using Microsoft.AspNetCore.Identity;

namespace ChicWear_ProjectAPI.Models
{
    public class ApplicationUser : IdentityUser
    {
        public string? Avatar { get; set; }
        public string? FullName { get; set; } 
        public ICollection<Order> Orders { get; set; } = new List<Order>();
    }
}