﻿using System.ComponentModel.DataAnnotations;

namespace ChicWear_ProjectAPI.ViewModels
{
    public class ShippingInfoViewModel
    {
        [Required]
        [MaxLength(100)]
        public string FullName { get; set; }

        [Required]
        [MaxLength(200)]
        public string Address { get; set; }

        [Required]
        [MaxLength(100)]
        public string City { get; set; }

        [Required]
        [MaxLength(20)]
        public string ZipCode { get; set; }
    }
}
